let buttonGaming1 = document.getElementById("rock_Button");
buttonGaming.addEventListener("click", play_Funcion1);

let buttonGaming2 = document.getElementById("paper_Button");
buttonGaming.addEventListener("click", play_Funcion2);

let buttonGaming3 = document.getElementById("scissors_Button");
buttonGaming.addEventListener("click", play_Funcion3);
 

function play_Funcion1(){
    function random(min, max){
        return Math.floor(Math.random()*(max - min + 1)+ min)
    }

    let contador = 0;
    contador++;
    
    let player = 0
    let pc = random (1,3)
    let rock = document.getElementById("rock")
    rock = 1 
    
    player = rock
    
    if(player == 1){
        alert("You chose Rock ");
    } else if (player == 2){
        alert("You chose Paper ");
    } else if (player == 3){
        alert("You chose Scissors ");
    }
    
    if(pc == 1){
        alert("PC chose Rock ");
    } else if (pc == 2){
        alert("PC chose Paper ");
    } else if (pc == 3){
        alert("PC chose Scissors ");
    }
    
    //Combate
    if(pc == player){
        alert("Tie")
    } else if((player == 1 && pc == 3 )||(player == 2 && pc == 1)||(player == 3 && pc == 2)){
        alert("You Won")
    }else{
        alert("You Lose")
    }
}

function play_Funcion2(){
    function random(min, max){
        return Math.floor(Math.random()*(max - min + 1)+ min)
    }

    let contador = 0;
    contador++;

    
    let player = 0
    let pc = random (1,3)
    let rock = document.getElementById("paper_Button")
    paper=2 
   
    player = paper
    
    if(player == 1){
        alert("You chose Rock ");
    } else if (player == 2){
        alert("You chose Paper ");
    } else if (player == 3){
        alert("You chose Scissors ");
    }
    
    if(pc == 1){
        alert("PC chose Rock ");
    } else if (pc == 2){
        alert("PC chose Paper ");
    } else if (pc == 3){
        alert("PC chose Scissors ");
    }
    
    //Combate
    if(pc == player){
        alert("Tie")
    } else if((player == 1 && pc == 3 )||(player == 2 && pc == 1)||(player == 3 && pc == 2)){
        alert("You Won")
    }else{
        alert("You Lose")
    }
}

function play_Funcion3(){
    function random(min, max){
        return Math.floor(Math.random()*(max - min + 1)+ min)
    }

    let contador = 0;
    contador++;
      
    let player = 0
    let pc = random (1,3)
    let scissors = document.getElementById("scissors_Button")
    scissors = 3
   
    player = scissors
    
    if(player == 1){
        alert("You chose Rock ");
    } else if (player == 2){
        alert("You chose Paper ");
    } else if (player == 3){
        alert("You chose Scissors ");
    }
    
    if(pc == 1){
        alert("PC chose Rock ");
    } else if (pc == 2){
        alert("PC chose Paper ");
    } else if (pc == 3){
        alert("PC chose Scissors ");
    }
    
    //Combate
    if(pc == player){
        alert("Tie")
    } else if((player == 1 && pc == 3 )||(player == 2 && pc == 1)||(player == 3 && pc == 2)){
        alert("You Won")
    }else{
        alert("You Lose")
    }
}


  miFuncion();